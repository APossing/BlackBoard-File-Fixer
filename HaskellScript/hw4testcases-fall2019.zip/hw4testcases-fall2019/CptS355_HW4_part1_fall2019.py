import re
#global variables
opstack = []  #assuming top of the stack is the end of the list
dictstack = []  #assuming top of the stack is the end of the list



#------- Operand Stack Operators --------------
#Pop a value from opstack.
def opPop():
    if len(opstack) > 0:
        x = opstack[len(opstack) - 1]
        opstack.pop(len(opstack) - 1)
        return x
    else:
        print("Error: opPop - Operand stack is empty")

#the Postscript pop; doesn't return the popped value
def pop():  
    if len(opstack) > 0:
        x = opstack[len(opstack) - 1]
        opstack.pop(len(opstack) - 1)
    else:
        print("Error: pop - Operand stack is empty")

#Push a value to opstack.
def opPush(value):
    opstack.append(value)
    
#Pop a value from dictstack.
def dictPop():
    if len(dictstack) > 0: 
        dictstack.pop(len(dictstack) - 1)
    else:
        print("Error: Pop - Operand stack is empty")

#------- Dict Stack Operators --------------
#pop the empty dictionary off the operand stack and push it on the dictstack
def dictPush(d):
    if isinstance(d,dict):
        dictstack.append(d)
    else:
        opPush(d)
        print("Error : DictPush - Expecting a dictionary on the top of the operand stack")
    
    
#add a variable definition to the top of the stack. Adds a new dictionary if the stack is empty. 
def define(name, value):
    if len(dictstack) > 0:
        dictstack[len(dictstack) - 1][name] = value
    else:
        newDict = {}
        newDict[name]= value
        dictstack.append(newDict)
        #opPush(newDict)
        #dictPush()

#search the dictstack for a variable or function (start searhing at the top of the stack)
def lookup(name):
    for d in reversed(dictstack): 
        if(d.get("/" + name, None) is not None): ##append '/' to name
            return d["/" + name]
    return None

#------- Arithmetic Operators --------------
##pop 2 values from stack; check if they are numerical (int or float); add them; push the result back to stack. 
def add():
    if len(opstack) > 1:
        op1 = opPop()
        op2 = opPop()
        if((isinstance(op1,int) or isinstance(op1, float))
           and (isinstance(op2,int) or isinstance(op2,float))):
            opPush(op1+op2)
        else:
            print("Error: add - one of the operands is not a numberical value")
            opPush(op1)
            opPush(op2)             
    else:
        print("Error: add expects 2 operands")

##pop 2 values from stack; check if they are numerical (int or float); subtract them; push the result back to stack. 
def sub():
    if len(opstack) > 1:
        op1 = opPop()
        op2 = opPop()
        if((isinstance(op1,int) or isinstance(op1, float))
           and (isinstance(op2,int) or isinstance(op2,float))):
            opPush(op2-op1)
        else:
            print("Error: sub - one of the operands is not a numberical value")
            opPush(op1)
            opPush(op2)             
    else:
        print("Error: sub expects 2 operands")

##pop 2 values from stack; check if they are numerical (int or float); multiply them; push the result back to stack. 
def mul():
    if len(opstack) > 1:
        op1 = opPop()
        op2 = opPop()
        if((isinstance(op1,int) or isinstance(op1, float))
           and (isinstance(op2,int) or isinstance(op2,float))):
            opPush(op1*op2)
        else:
            print("Error: mul - one of the operands is not a numberical value")
            opPush(op1)
            opPush(op2)             
    else:
        print("Error: mul expects 2 operands")

##pop 2 values from stack; check if they are numerical (int or float); divide the top value with the other; push the result back to stack. 
def div():
    if len(opstack) > 1:
        op1 = opPop()
        op2 = opPop()
        if((isinstance(op1,int) or isinstance(op1, float))
           and (isinstance(op2,int) or isinstance(op2,float))):
            opPush(op2/op1)
        else:
            print("Error: div - one of the operands is not a numberical value")
            opPush(op1)
            opPush(op2)             
    else:
        print("Error: div expects 2 operands")
            
##pop 2 values from stack; check if they are numerical (int or float); calculate the mod; push the result back to stack.         
def mod():
    if len(opstack) > 1:
        op1 = opPop()
        op2 = opPop()
        if((isinstance(op1,int) or isinstance(op1, float))
           and (isinstance(op2,int) or isinstance(op2,float))):
            opPush(op2 % op1)
        else:
            print("Error: div - one of the operands is not a numberical value")
            opPush(op1)
            opPush(op2)             
    else:
        print("Error: div expects 2 operands")

def eq():
    if len(opstack) > 1:
        op1 = opPop()
        op2 = opPop()
        opPush(op2 == op1)
    else:
        print("Error: eq expects 2 operands")

def lt():
    if len(opstack) > 1:
        op1 = opPop()
        op2 = opPop()
        opPush(op2 < op1)
    else:
        print("Error: lt expects 2 operands")

def gt():
    if len(opstack) > 1:
        op1 = opPop()
        op2 = opPop()
        opPush(op2 > op1)
    else:
        print("Error: gt expects 2 operands")



# ------- String Operators --------------
# Pops a array value from the operand stack and calculates the length of it. Pushes the length back to the stack.
def slength():
    if len(opstack) > 0:
        sInput = opPop()
        if (isinstance(sInput, list)):
            opPush(len(sInput))
        else:
            print("Error: length expects an array argument")
            opPush(sInput)
    else:
        print("Error: length - not enough arguments")

# Pops a array value and an index from the operand stack and pushes the ascii value of the the character in the string at the index onto the opstack
def sget():
    if len(opstack) > 1:
        ind = opPop()
        sInput = opPop()
        if (isinstance(sInput, list) and isinstance(ind, int)):
            opPush(sInput[ind])
        else:
            print("Error: get expects an array and an integer argument")
            opPush(sInput)
            opPush(ind)
    else:
        print("Error: get - not enough arguments")
# Pops a string value, an index, and an ascii character from the operand stack, updates the character at the index position of the string with the ascii character. The result is not pushed onto the stack.
def sput():
    if len(opstack) > 2:
        asciiVal = opPop()
        ind = opPop()
        sInput = opPop()

        if (isinstance(sInput, str) and isinstance(ind, int) and isinstance(asciiVal, int)):
            sList = list(sInput)
            sList[ind] = chr(asciiVal)
            return ("".join(sList))
        else:
            print("Error: put expects a string and 2 integer arguments")
            opPush(sInput)
            opPush(ind)
            opPush(asciiVal)
            return "";
    else:
        print("Error: put - not enough arguments")
        return "";

# Pops a string, an integer index, and a count from stack.
# Extracts count characters from the string starting from index.
def sgetinterval():
    if len(opstack) > 2:
        count = opPop()
        startIndex = opPop()
        sInput = opPop()
        if (isinstance(sInput, str) and isinstance(count, int) and isinstance(startIndex, int)):
            if sInput[0] == '(' and sInput[-1] == ')':
                opPush('('+sInput[startIndex + 1 : startIndex + 1 + count]+')')
            else: print("Error: getInterval -  string is not enclosed in paranthesis")
        else:
            print("Error: getInterval expects a string and 2 integer arguments")
            opPush(sInput)
            opPush(startIndex)
            opPush(count)
    else:
        print("Error: getinterval - not enough arguments")

#----Boolean Operators-----------
def psAnd():
    if len(opstack) > 1:
        op1 = opPop()
        op2 = opPop()
        if (isinstance(op1, bool) and isinstance(op2, bool)):
            opPush(op2 and op1)
        else:
            print("Error: psAnd - operands are booleans values")
            opPush(op1)
            opPush(op2)
    else:
        print("Error: psAnd expects 2 operands")

def psOr():
    if len(opstack) > 1:
        op1 = opPop()
        op2 = opPop()
        if (isinstance(op1, bool) and isinstance(op2, bool)):
            opPush(op2 or op1)
        else:
            print("Error: psOr - operands are booleans values")
            opPush(op1)
            opPush(op2)
    else:
        print("Error: psOr expects 2 operands")

def psNot():
    if len(opstack) > 0:
        op1 = opPop()
        if isinstance(op1, bool):
            opPush( not op1)
        else:
            print("Error: psNot - operands are booleans values")
            opPush(op1)
    else:
        print("Error: psNot expects 1 operand")

#------- Array Operators --------------
#Pops an array value from the operand stack and calculates the length of it. Pushes the length back to the stack.
def length():
    if len(opstack) > 0:
        aInput = opPop()
        if(isinstance(aInput, tuple)):
            opPush(len(aInput[1]))
        else:
           print("Error: length expects an array argument")
           opPush(aInput)
    else:
        print("Error: length - not enough arguments")
        
#Pops a array value and an index from the operand stack and pushes the value at the index position of the array onto the opstack
def get():
    if len(opstack) > 1:
        ind = opPop()
        aInput = opPop()
        if(isinstance(aInput,tuple) and isinstance(ind, int)):
            if aInput[0] > ind:  #check if the ind is out of bound; compare it to the length of the array
                opPush(aInput[1][ind])
            else:
                print("Error: array length - index out of bound")
        else:
            print("Error: get expects a string and an integer argument")
            opPush(aInput)
            opPush(ind)
    else:
        print("Error: get - not enough arguments")


# Pops an array value, an index, and a value from the operand stack, updates the value at the index position of the array with the given value. The result is not pushed onto the stack.
def put():
    if len(opstack) > 2:
        val = opPop()
        ind = opPop()
        aInput = opPop()

        if (isinstance(aInput, tuple) and isinstance(ind, int) and isinstance(val, int)):
            if (ind < len(aInput[1])):
                aInput[1][ind] = val
            else:
                raise Exception("Error: array put - index out of bound")
        else:
            opPush(aInput)
            opPush(ind)
            opPush(val)
            raise Exception("Error: put expects an array (tuple) and 2 integer arguments")
    else:
        raise Exception("Error: put - not enough arguments")
        return ""

#helper function evaluating the array values 
def evaluateArray(aInput):
    result = []
    opPush('[')
    for item in aInput[1]:
        if isInt(item) or isBool(item): #int or bool constant
            opPush(item)
        elif item in builtinFunctions:  #an operator
            builtinFunctions[item]()
        else: 
            val = lookup(item)
            if val is not None:
                opPush(val)
            else:
                print("Error!- unexpected token in the array")
    item = opPop()
    while item != '[':
        result = [item] + result
        item = opPop()
    return (len(result), result)

#loads the array elements to stack
def aload():
    if len(opstack) > 0:
        aInput = opPop()

        if isinstance(aInput, tuple):
            for item in aInput[1]:
                if isInt(item) or isBool(item): #int or bool constant
                    opPush(item)
                else:
                    print("Error!- aload - unexpected token in the array")
        else:
            print("Error: aload expects an array argument")
            opPush(aInput)
            return ""
        opPush(aInput)
    else:
        print("Error: aload - not enough arguments")
        return ""
    

def astore():
    if len(opstack) > 0:
        aInput = opPop()
        if isinstance(aInput, tuple):
            for i in range(1,len(aInput[1])+1):
                item = opPop()
                if isInt(item) or isBool(item): #int or bool constant
                    aInput[1][-i]= item
                else:
                    print("Error!- aload - unexpected token in the array")
        else:
            print("Error: aload expects an array argument")
            opPush(aInput)
            return ""
        opPush(aInput)
    else:
        print("Error: aload - not enough arguments")
        return ""

def forall():
    if len(opstack) > 1:
        fbody = opPop()
        aInput = opPop()
        if (isinstance(aInput, tuple) and isinstance(fbody, list)):
            for x in aInput[1]:
                opPush(x)  # push the array element onto the stack
                interpretSPS(fbody)
        else:
            print("Error: forall expects an array and a codearray")
            opPush(aInput)
            opPush(fbody)
    else:
        print("Error: get - not enough arguments")




#------- Stack Manipulation and Print Operators --------------

#copies top element in opstack
def dup():
    if len(opstack) > 0:
        op1 = opPop()
        opPush(op1)
        opPush(op1)
    else:
        print("Error: dup - not enough arguments")

#pops an integer count from stack, copies count characters and pushes them back to stack. 
def copy():
    if(len(opstack) > 0):
        count = opPop()
        copyList = []
        for  x in range(0,count):
            copyList.append(opPop())
        for item in reversed(copyList):
            opPush(item)
        for item in reversed(copyList):
            opPush(item)
    else:
        print("Error: copy - not enough arguments")

#counts the number of elements in the stack and pushes the count onto the top of the stack
def count():
    opPush(len(opstack))

#pops the top value from the operand stack
def pop ():
    if (len(opstack) > 0):
        opPop()
    else:
        print("Error: copy - not enough arguments")

#clears the stack
def clear():
    opstack[:] = []
    
#prints the stack
def stack():
    for item in reversed(opstack):
        if isinstance(item,tuple):
            print(item[1])
        else:
            print(item)
        
#swaps the top two elements in opstack
def exch():
    if len(opstack) > 1:
        op1 = opPop()
        op2 = opPop()
        opPush(op1)
        opPush(op2)
    else:
        print("Error: exch - not enough arguments")

#Pops 2 integer values m and n from stack, rolls the top m values n times (if n is positive roll clockwise, otherwise roll countercloackwise)
def roll():
    if len(opstack) > 1:
        n = opPop()
        m = opPop()
        copyList = []
        for x in range(0,m):
            copyList.append(opPop())
        if (n>0): 
            copyList[len(copyList):] = copyList[0:n]
            copyList[0:n]=[]
        else:
            copyList[:0]=copyList[n:]
            copyList[n:]=[]
       
        for x in reversed(copyList[0:]):
            opPush(x)
        del copyList[:]
          
    else:
       print("Error: roll - not enough arguments")



#creates a new empty dictionary  pushes it on the opstack
def psDict():
    if len(opstack) > 0:
        n = opPop() # n is the initial size of the dictionary ; discard      
        opPush({})
    else:
        print("Error: psDict - not enough arguments")

def begin():
    dictPush(opPop())

def end():
    dictPop()
    
#pops a name and a value from stack, adds the definition to the dictstack. 
def psDef():
    if len(opstack) > 1:
        value = opPop()
        name = opPop()
        if(isinstance(name,str)):
            define(name, value)
        else:
            opPush(name)
            opPush(value)
            print("Error: psDef - invalid name argument")
    else:
        print("Error: psDef - not enough arguments")

# ------- if/ifelse Operators --------------

# if
def psIf():
    if len(opstack) > 1:
        ifBody = opPop()
        cond = opPop()
        if isinstance(cond,bool) and isinstance(ifBody,list):
            if cond:
                interpretSPS(ifBody)
        else:
            print("Error: psIf - invalid argument")
    else:
        print("Error: psIf - not enough arguments")

# if
def psIfelse():
    if len(opstack) > 2:
        elseBody = opPop()
        ifBody = opPop()
        cond = opPop()
        if isinstance(cond, bool) and isinstance(ifBody, list) and isinstance(elseBody,list):
            if cond:
                interpretSPS(ifBody)
            else:
                interpretSPS(elseBody)
        else:
            print("Error: psIf - invalid argument")
    else:
        print("Error: psIf - not enough arguments")


#------- Loop Operators --------------

#for loop
def psFor():
    forBody = opPop()
    end = opPop()
    inc = opPop()
    begin = opPop()
    if inc < 0:
        end -= 1
    else:
        end += 1
    for x in range(begin,end,inc):
        opPush(x) #push the loop index onto stack at each iteration
        interpretSPS(forBody)

#------- Helper functions-----------------       
def isInt(s):
    try:
        int(s)
        return True
    except ValueError:
        return False

def onlyInts(L):
    for item in L:
        if not isinstance(item,int):
            return False
    return True

def isBool(s):
    if s in ['true', 'false']:
        return True
    else:
        return False

def toBool(s):
    if s=='true':
        return True
    elif s=='false':
        return False
    else:
        print("Error: toBool - invalid argument")
