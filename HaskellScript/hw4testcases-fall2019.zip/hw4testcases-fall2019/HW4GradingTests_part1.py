import unittest
from HW4_part1_mitch import *

class HW4GradingTests_part1(unittest.TestCase):

    #If the setUp doesn't clear the stacks succesfully, copy the following function to HW4_part1.py and call it in setup. 
    def clearStacks():
        del opstack[:]
        del dictstack[:]

    def printTestInput(self,funcName, input,pts):
        # print("-------------------------")
        print("\n{funcName} (input: {input}) - {pts} ".format(funcName=funcName,input=input,pts=pts))

    def my_psDef():
        if len(opstack) > 1:
            value = opPop()
            name = opPop()
            if(isinstance(name,str)):
                define(name, value)
            else:
                print("Error: psDef - invalid name argument")
        else:
            print("Error: psDef - not enough arguments")

    def my_psDict():
        if len(opstack) > 0:
            n = opPop() # n is the initial size of the dictionary ; discard
            opPush({})
        else:
            print("Error: psDict - not enough arguments")

    def my_begin():
        dictPush(opPop())

    def my_end():
        dictPop()    

    def setUp(self):
        #clear the opstack and the dictstack
        opstack [:] = []
        dictstack [:] = []
            
    # 3 pts
    def test_lookup(self):
        self.printTestInput("lookup-1", '/v 3 def /x 20 def dict begin /v 4 def /x 10 def dict begin /v 5 def x ', '3 pts')
        dictPush({'/v':3, '/x': 20})
        dictPush({'/v':4, '/x': 10})
        dictPush({'/v':5})
        self.assertEqual(lookup('x'),10)

    #2 pts
    def testLookup2(self):
        self.printTestInput("lookup-2", '/a 355 def dict begin /a [3 5 5] def a', '2 pts')
        dictPush({'/a':355})
        dictPush({'/a':(3,[3,5,5])})
        self.assertEqual(lookup("a"),(3,[3,5,5]))

    # 2 pts
    def test_define(self):
        self.printTestInput("define-1",'/n1 4 def 1 dict begin /n2 10 def n1', '2 pts')
        dictPush({})
        define("/n1", 4)
        dictPush({})
        define("/n2",10)
        self.assertEqual(lookup("n1"),4)

    # 3 pts
    def test_define2(self):
        self.printTestInput("define-2", '/n1 4 def /n1 5 def n1', '3 pts')
        dictPush({})
        define("/n1", 4)
        define("/n1", 5)
        self.assertEqual(lookup("n1"),5)

    #Arithmatic operator tests
    #2 pts
    def test_add(self):
        self.printTestInput("add", '9 3 add','2 pts')
        opPush(9)
        opPush(3)
        add()
        self.assertEqual(opPop(),12)

    #2 pts
    def test_sub(self):
        self.printTestInput("sub", '10 2 sub','2 pts')
        opPush(10)
        opPush(2)
        sub()
        self.assertEqual(opPop(),8)

    #2 pts
    def test_mul(self):
        self.printTestInput("mul", '2 40 mul','2 pts')
        opPush(2)
        opPush(40)
        mul()
        self.assertEqual(opPop(),80)
   
    #Comparison operators tests
    # 2 pts
    def test_eq1(self):
        self.printTestInput("eq", '6 6 eq','2 pts')
        opPush(6)
        opPush(6)
        eq()
        self.assertEqual(opPop(),True)

    # 1 pts
    def test_eq2(self):
        self.printTestInput("eq", '[1 2 3 4] [4 3 2 1] eq','1 pts')
        opPush((4,[1,2,3,4]))
        opPush((4,[4,3,2,1]))
        eq()
        self.assertEqual(opPop(),False)

    # 3 pts
    def test_lt(self):
        self.printTestInput("lt", '3 6 lt','3 pts')
        opPush(3)
        opPush(6)
        lt()
        self.assertEqual(opPop(),True)

    # 3 pts
    def test_gt(self):
        self.printTestInput("gt", '4 5 gt','3 pts')
        opPush(4)
        opPush(5)
        gt()
        self.assertEqual(opPop(),False)

    #stack manipulation functions
    # 3 pts
    def test_dup(self):
        self.printTestInput("dup", "[3 5 5 True 4]  dup dup dup ",'3 pts')
        opPush((5,[3,5,5,True,4]))
        dup()
        dup()
        dup()
        isSame = (opPop()[1] is opPop()[1]) and (opPop()[1] is opPop()[1]) 
        self.assertTrue(isSame)


    # 5 pts
    def test_exch(self):
        self.printTestInput("exch", '/x [1 2 3] exch','5 pts')
        opPush('/x')
        opPush((3,[1,2,3]))
        exch()
        self.assertEqual(opPop(),'/x')
        self.assertEqual(opPop(),(3,[1,2,3]))

    # 2 pts
    def test_pop(self):
        self.printTestInput("pop", '10 pop','2 pts')
        l1 = len(opstack)
        opPush(10)
        pop()
        l2 = len(opstack)
        self.assertEqual(l1,l2)

    # 5 pts
    def test_copy(self):
        self.printTestInput("copy", 'true 1 [1 2] 3 4 3 copy','5 pts')
        opPush(True)
        opPush(1)
        opPush((2,[1,2]))
        opPush(3)
        opPush(4)
        opPush(3)
        copy()
        self.assertTrue(opPop()==4 and opPop()==3 and opPop()==(2,[1,2]) and opPop()==4 and opPop()==3 and opPop()==(2,[1,2]) and opPop()==1)
        
    # 3 pts
    def test_clear(self):
        self.printTestInput("clear", '10 /x clear','3 pts')
        opPush(10)
        opPush("/x")
        clear()
        self.assertEqual(len(opstack),0)

    #Array operator tests
    #5 pts
    def test_length(self):
        self.printTestInput('length', "1 [3 5 5 True 3 2 2] length  (length should not push back the array onto the stack)",'5 pts')
        opPush(1)
        opPush((7,[3,5,5,True,3,2,2]))
        length()
        self.assertEqual(opPop(),7)      

    # 5 pts
    def test_get(self):
        self.printTestInput('get', "1 [3 5 5 True 3 2 2] 3 get (get should not push back the array onto the stack)",'5 pts')
        opPush(1)
        opPush((7,[3,5,5,True,3,2,2]))
        opPush(3)
        get()
        self.assertEqual(opPop(),True)      

    # 3 pts
    def test_put1(self):
        self.printTestInput('put', "1 [3 5 5 True 3 2 2] dup 4 4 put  (put should not push the array back onto the stack. This test is making sure that it is not pushed back. )",'2 pts')
        opPush(1)
        opPush((7,[3,5,5,True,3,2,2]))
        dup()
        opPush(4)
        opPush(4)
        put()
        self.assertTrue(opPop()[1]==[3,5,5,True,4,2,2] and opPop()==1)      

    # 2 pts
    def test_put2(self):
        self.printTestInput('put', "/x [3 5 5 True 4] def  x 2 0 put x",'2 pts')
        x = (5,[3,5,5,True,4])
        define('/x',x)
        opPush(x)
        opPush(2)
        opPush(0)
        put()
        self.assertEqual(lookup('x')[1],[3,5,0,True,4])      

    # 3 pts
    def test_put3(self):
        self.printTestInput('put', "[3 5 5 True 4] dup /x exch def 2 0 put x",'3 pts')
        opPush((5,[3,5,5,True,4]))
        dup()
        opPush('/x')
        exch()
        psDef()
        opPush(2)
        opPush(0)
        put()
        self.assertEqual(lookup('x')[1],[3,5,0,True,4])      

    # 5 pts
    def test_aload(self):
        self.printTestInput('aload', "[3 5 5 True 3 2 2] aload",'5 pts')
        opPush((7,[3,5,5,True,3,2,2]))
        aload()
        self.assertTrue(opPop()[1]==[3,5,5,True,3,2,2] and opPop()== 2 and opPop()==2 and opPop()==3 and opPop()==True and opPop() == 5 and opPop() == 5 and opPop()==3)  

    # 5 pts
    def test_astore(self):
        self.printTestInput('astore', "1 2 3 4 True 5 6  [None,None,None,0] astore",'5 pts')
        opPush(1)
        opPush(2)
        opPush(3)
        opPush(4)
        opPush(True)
        opPush(5)
        opPush(6)
        opPush((4,[None,None,None,0]))  # the array doesn't necessarily neeed to have None values. 
        astore()
        self.assertTrue(opPop()[1]==[4,True,5,6] and opPop()==3 and opPop()==2 and opPop()==1)  


    #dictionary stack operators
    # 3 pts
    def test_dict(self):
        self.printTestInput("dict", '1 dict','3 pts')
        opPush(1)
        psDict()
        self.assertEqual(opPop(),{})

    # 5 pts
    def test_psDef(self):
        self.printTestInput("psDef", '/x 10 def /x 20 def /y 30 def x','5 pts')
        dictPush({})
        opPush("/x")
        opPush(10)
        psDef()
        opPush("/x")
        opPush(20)
        psDef()
        opPush("/y")
        opPush(30)
        psDef()
        self.assertEqual(lookup('x'),20)

    # 4 pts
    def test_psDef2(self):
        self.printTestInput("psDef-2", '/x 10 def 1 dict begin /y 20 def x','4 pts')
        dictPush({})
        opPush("/x")
        opPush(10)
        psDef()
        dictPush({})
        opPush("/y")
        opPush(20)
        psDef()
        self.assertEqual(lookup('x'),10)

    # 5 pts
    def test_beginEnd(self):
        self.printTestInput("begin-end", '1 dict begin /x 1 def /y 2 def 1 dict begin /x 3  def end /y 4 def x y','5 pts')
        opPush(1)
        psDict()
        begin()
        opPush("/x")
        opPush(1)
        psDef()
        opPush('/y')
        opPush(2)
        psDef()
        opPush(1)
        psDict()
        begin()
        opPush("/x")
        opPush(3)
        psDef()
        end() 
        opPush('/y')
        opPush(4)
        psDef()
        self.assertTrue(lookup('x')==1 and lookup('y')==4)

    # 5 pts
    def test_psDef3(self):
        self.printTestInput("psDef3", '/x 3 def /y 4 def 1 dict begin /x 30 def 1 dict begin /x 300 def end x y','5 pts')
        # define x and y in the bottom dictionary
        dictPush({})
        opPush("/x")
        opPush(3)
        psDef()
        opPush('/y')
        opPush(4)
        psDef()
        # define x in the second dictionary
        dictPush({})
        opPush("/x")
        opPush(30)
        psDef()
        # define x in the third dictionary
        dictPush({})
        opPush("/x")
        opPush(300)
        psDef()
        dictPop()
        self.assertTrue(lookup('x')==30 and lookup('y')==4)

    #Tests to check "input error checking"

    #  Make sure that the following test prints/raises an error message about the type of the second argument
    #  Also make sure that the opstack content is : 123 0 10 
    # 3 pts
    def test_putInputs(self):
        self.printTestInput("test put inputs: ", "(123 0 10 put)", '3 pts')
        opPush(123)
        opPush(0)
        opPush(10)
        try:
            put()
        except Exception as e:
            print("Raised exception:   ", str(e))
        print('opstack:')
        stack()

    # Make sure that the following test prints/raises an error message about the type of the first argument (the variable name needs be a string)
    # Make sure that the stack content is : 1 /x
    # 2 pts
    def test_psDefInputs(self):
        self.printTestInput("test psDef inputs: ", "(1 /x def)", '2 pts')
        opPush(1)
        opPush('/x')
        try:
            psDef()
        except Exception as e:
            print("Raised exception :   ", str(e))
        print('opstack:')
        stack()

    # Make sure that the following test prints/raises an error message about the type of the argument (needs to be array (i.e., tuple)) 
    # Make sure that the stack content is : [1,2,3]
    # 2 pts
    def test_psaloadInputs(self):
        self.printTestInput("test aLoad inputs: ", "[1,2,3] aload", "2 pts")
        opPush('[1,2,3]')
        try:
            aload()
        except Exception as e:
            print("Raised exception :   ", str(e))
        stack()

if __name__ == '__main__':
    unittest.main()

